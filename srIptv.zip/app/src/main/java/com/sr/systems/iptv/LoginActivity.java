package com.sr.systems.iptv;

import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import android.provider.Settings;

// Import necessário para UiModeManager
import android.app.UiModeManager;
import android.content.res.Configuration;
import android.content.pm.ActivityInfo;
// Adicione este código em um bloco de código Java no Sketchware
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.widget.Toast;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.util.Log;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.util.HashMap;
import java.util.Map;


public class LoginActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private String macAddress = "";
	private String androidId = "";
	private String token = "";
	private HashMap<String, Object> params = new HashMap<>();
	private String url = "";
	private double p = 0;
	private String getMac = "";
	private HashMap<String, Object> maps = new HashMap<>();
	private String getUser = "";
	private String getSenha = "";
	private String getDns = "";
	private HashMap<String, Object> userInfoMap = new HashMap<>();
	private HashMap<String, Object> serverInfoMap = new HashMap<>();
	
	private ArrayList<HashMap<String, Object>> mp = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private TextView macIndo;
	private TextView textview2;
	private TextView mac;
	private LinearLayout linear3;
	private LinearLayout linear5;
	private ImageView imageview1;
	private TextView textview1;
	private TextView textview3;
	
	private DatabaseReference iptv = _firebase.getReference("iptv");
	private ChildEventListener _iptv_child_listener;
	private AlertDialog.Builder dia;
	private RequestNetwork verifique;
	private RequestNetwork.RequestListener _verifique_request_listener;
	private TimerTask yime;
	private Intent vo = new Intent();
	private TimerTask uu;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.login);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		
		// Obter o UiModeManager
		UiModeManager uiModeManager = (UiModeManager) getSystemService(UI_MODE_SERVICE);
		
		// Verificar se é um celular
		if (uiModeManager.getCurrentModeType() == Configuration.UI_MODE_TYPE_NORMAL) {
				    // É um celular, definir a orientação para vertical
				    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		} else {
				    // Não é um celular (pode ser tablet ou TV), definir a orientação para horizontal
				    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		}
		
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		macIndo = findViewById(R.id.macIndo);
		textview2 = findViewById(R.id.textview2);
		mac = findViewById(R.id.mac);
		linear3 = findViewById(R.id.linear3);
		linear5 = findViewById(R.id.linear5);
		imageview1 = findViewById(R.id.imageview1);
		textview1 = findViewById(R.id.textview1);
		textview3 = findViewById(R.id.textview3);
		dia = new AlertDialog.Builder(this);
		verifique = new RequestNetwork(this);
		
		_iptv_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		iptv.addChildEventListener(_iptv_child_listener);
		
		_verifique_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (_response.contains("html")) {
					macIndo.setText("Usuário Sendo gerado aguarde por 2 minutos, caso nao comece a reproduzir entre em contado com o vendedor");
					yime = new TimerTask() {
						@Override
						public void run() {
							runOnUiThread(new Runnable() {
								@Override
								public void run() {
									verifique.startRequestNetwork(RequestNetworkController.GET, getDns.concat("/player_api.php?username=".concat(getUser.concat("&password=".concat(getSenha.concat(""))))), "", _verifique_request_listener);
								}
							});
						}
					};
					_timer.schedule(yime, (int)(10000));
					SketchwareUtil.showMessage(getApplicationContext(), _response);
				}
				else {
					if (_response.contains("error")) {
						macIndo.setText("Usuário Sendo gerado aguarde por 2 minutos, caso nao comece a reproduzir entre em contado com o vendedor");
						uu = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										verifique.startRequestNetwork(RequestNetworkController.GET, getDns.concat("/player_api.php?username=".concat(getUser.concat("&password=".concat(getSenha.concat(""))))), "", _verifique_request_listener);
									}
								});
							}
						};
						_timer.schedule(uu, (int)(10000));
						SketchwareUtil.showMessage(getApplicationContext(), _response);
					}
					else {
						vo.setClass(getApplicationContext(), MainActivity.class);
						startActivity(vo);
						finish();
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		
		mac.setText(getIntent().getStringExtra("mac"));
		if (getIntent().getStringExtra("ver").equals("vencido")) {
			macIndo.setText("SEU USUÁRIO ESTA VENCIDO ENTRE EM CONTATO COM SEU VENDEDOR");
		}
		else {
			if (getIntent().getStringExtra("ver").equals("falha")) {
				macIndo.setText("HOUVE UMA FALHA AO GERAR O TESTE AUTOMÁTICO,  ENTRE EM CONTATO COM SEU VENDEDOR ");
			}
			else {
				iptv.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						mp = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								mp.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						p = 0;
						for(int _repeat24 = 0; _repeat24 < (int)(mp.size()); _repeat24++) {
							if (mac.getText().toString().contains(mp.get((int)p).get("mac").toString())) {
								getUser = mp.get((int)p).get("usuario").toString();
								getSenha = mp.get((int)p).get("senha").toString();
								getDns = mp.get((int)p).get("dns").toString();
							}
							else {
								p++;
							}
						}
						uu = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										verifique.startRequestNetwork(RequestNetworkController.GET, getDns.concat("/player_api.php?username=".concat(getUser.concat("&password=".concat(getSenha.concat(""))))), "g", _verifique_request_listener);
									}
								});
							}
						};
						_timer.schedule(uu, (int)(10000));
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
		}
	}
	
	
	@Override
	public void onBackPressed() {
		dia.setMessage("Deseja sair?");
		dia.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				finishAffinity();
			}
		});
		dia.setNeutralButton("Não", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				
			}
		});
		dia.create().show();
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}