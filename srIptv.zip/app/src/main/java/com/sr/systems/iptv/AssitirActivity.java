package com.sr.systems.iptv;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bumptech.glide.Glide;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import org.json.JSONArray;
import org.json.JSONObject;
// Adicione este código em um bloco de código Java no Sketchware
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.widget.Toast;
import java.util.List;
// Import necessário para UiModeManager
import android.app.UiModeManager;
import android.content.res.Configuration;
import android.content.pm.ActivityInfo;


public class AssitirActivity extends AppCompatActivity {
	
	private String streamid = "";
	private String arquivo = "";
	private HashMap<String, Object> dataMap = new HashMap<>();
	private HashMap<String, Object> infoMap = new HashMap<>();
	private double p = 0;
	private HashMap<String, Object> episodiosMap = new HashMap<>();
	private String posicaoTemporada = "";
	private String url = "";
	private String p2 = "";
	private String posicaoTemporada1 = "";
	
	private ArrayList<HashMap<String, Object>> listMap = new ArrayList<>();
	private ArrayList<String> str = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> temporada = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> mm = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> melhorAvaliadaos = new ArrayList<>();
	
	private ImageView imageview1;
	private LinearLayout linear1;
	private TextView textview2;
	private LinearLayout linear2;
	private TextView descrition;
	private LinearLayout linear4;
	private ListView listview2;
	private TextView nome;
	private HorizontalScrollView hscroll2;
	private LinearLayout linear_g1;
	private ListView listview1;
	
	private RequestNetwork obterInfor;
	private RequestNetwork.RequestListener _obterInfor_request_listener;
	private Intent vs = new Intent();
	private RequestNetwork img;
	private RequestNetwork.RequestListener _img_request_listener;
	private Intent intent = new Intent();
	private SharedPreferences s;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.assitir);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		
		// Obter o UiModeManager
		UiModeManager uiModeManager = (UiModeManager) getSystemService(UI_MODE_SERVICE);
		
		// Verificar se é um celular
		if (uiModeManager.getCurrentModeType() == Configuration.UI_MODE_TYPE_NORMAL) {
				    // É um celular, definir a orientação para vertical
				    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		} else {
				    // Não é um celular (pode ser tablet ou TV), definir a orientação para horizontal
				    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		}
		
		imageview1 = findViewById(R.id.imageview1);
		linear1 = findViewById(R.id.linear1);
		textview2 = findViewById(R.id.textview2);
		linear2 = findViewById(R.id.linear2);
		descrition = findViewById(R.id.descrition);
		linear4 = findViewById(R.id.linear4);
		listview2 = findViewById(R.id.listview2);
		nome = findViewById(R.id.nome);
		hscroll2 = findViewById(R.id.hscroll2);
		linear_g1 = findViewById(R.id.linear_g1);
		listview1 = findViewById(R.id.listview1);
		obterInfor = new RequestNetwork(this);
		img = new RequestNetwork(this);
		s = getSharedPreferences("s", Activity.MODE_PRIVATE);
		
		listview2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				url = s.getString("dns", "").concat("/series/".concat(s.getString("usuario", "").concat("/".concat(s.getString("senha", "").concat("/"))))).concat(mm.get((int)_position).get("id").toString().concat(".".concat(mm.get((int)_position).get("container_extension").toString())));
				// Verifica se o VLC está instalado
				    PackageManager packageManager = getPackageManager();
				    Intent intent = new Intent(Intent.ACTION_VIEW);
				    intent.setDataAndType(Uri.parse(url), "video/*");
				    List<ResolveInfo> resolveInfoList = packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
				
				    boolean vlcInstalled = false;
				    for (ResolveInfo resolveInfo : resolveInfoList) {
					        if (resolveInfo.activityInfo.packageName.equals("org.videolan.vlc")) {
						            vlcInstalled = true;
						            break;
						        }
					    }
				
				    if (vlcInstalled) {
					        // Cria uma Intent para abrir o VLC com a URL
					        Intent vlcIntent = new Intent(Intent.ACTION_VIEW);
					        vlcIntent.setDataAndType(Uri.parse(url), "video/*");
					        vlcIntent.setPackage("org.videolan.vlc");
					        startActivity(vlcIntent);
					    } else {
					        // Solicita ao usuário que baixe o VLC
					         
					        Intent playStoreIntent = new Intent(Intent.ACTION_VIEW);
					        playStoreIntent.setData(Uri.parse("market://details?id=org.videolan.vlc"));
					        startActivity(playStoreIntent);
					    }
			}
		});
		
		listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				posicaoTemporada1 = temporada.get((int)_position).get("posicao").toString();
				// Inicializa a List<Map<String, Object>> para armazenar os episódios
				List<Map<String, Object>> listaEpisodio = new ArrayList<>();
				
				// Obtém o mapa de temporadas do objeto dataMap
				Map<String, Object> episodesMap = (Map<String, Object>) dataMap.get("episodes");
				
				// Acessa a lista de episódios da Temporada 1
				List<Map<String, Object>> episodiosDaTemporada1 = (List<Map<String, Object>>) episodesMap.get(posicaoTemporada1);
				
				// Itera sobre os episódios da Temporada 1
				for (Map<String, Object> episodio : episodiosDaTemporada1) {
					    // Cria um novo Map para armazenar as informações de cada episódio
					    Map<String, Object> episodioMap = new HashMap<>();
					
					    // Obtém os valores das chaves
					    String id = (String) episodio.get("id");
					    String episodeNum = (String) episodio.get("episode_num");
					    String title = (String) episodio.get("title");
					    String containerExtension = (String) episodio.get("container_extension");
					    
					    // Obtém informações adicionais do mapa 'info'
					    Map<String, Object> infoMap = (Map<String, Object>) episodio.get("info");
					    String plot = (String) infoMap.get("plot");
					    String duration = (String) infoMap.get("duration");
					
					    // Armazena as informações no Map
					    episodioMap.put("id", id);
					    episodioMap.put("episode_num", episodeNum);
					    episodioMap.put("title", title);
					    episodioMap.put("container_extension", containerExtension);
					    episodioMap.put("plot", plot);
					    episodioMap.put("duration", duration);
					
					    // Adiciona o Map à lista
					    listaEpisodio.add(episodioMap);
				}
				
				// Exibe os itens armazenados em listaEpisodio
				for (Map<String, Object> episodio : listaEpisodio) {
					    System.out.println("ID: " + episodio.get("id"));
					    System.out.println("Episódio: " + episodio.get("episode_num"));
					    System.out.println("Título: " + episodio.get("title"));
					    System.out.println("Extensão do arquivo: " + episodio.get("container_extension"));
					    System.out.println("Duração: " + episodio.get("duration"));
					    System.out.println("Enredo: " + episodio.get("plot"));
					    System.out.println("----------------------------");
				}
				
				FileUtil.writeFile(FileUtil.getExternalStorageDir().concat("/teste/teste.json"), new Gson().toJson(listaEpisodio));
				_tempo();
			}
		});
		
		_obterInfor_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				dataMap = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
				FileUtil.writeFile(FileUtil.getExternalStorageDir().concat("/tt/tt.json"), _response);
				Map<String, Object> infoMap = (Map<String, Object>) dataMap.get("info");
				
				List<String> backdropPathList = (List<String>) infoMap.get("backdrop_path");
				if (backdropPathList != null && !backdropPathList.isEmpty()) {
							infoMap.put("backdrop_path", backdropPathList.get(0)); // Atualiza o mapa com o primeiro item da lista
				}
				
				Map<String, Object> episodiosMap = (Map<String, Object>) dataMap.get("episodes");
				Glide.with(getApplicationContext()).load(Uri.parse(infoMap.get("backdrop_path").toString())).into(imageview1);
				nome.setText(infoMap.get("name").toString());
				descrition.setText(infoMap.get("plot").toString());
				SketchwareUtil.getAllKeysFromMap(episodiosMap, str);
				p = 0;
				posicaoTemporada1 = str.get((int)(0));
				for(int _repeat111 = 0; _repeat111 < (int)(str.size()); _repeat111++) {
					{
						HashMap<String, Object> _item = new HashMap<>();
						_item.put("posicao", str.get((int)(p)));
						temporada.add(_item);
					}
					
					p++;
				}
				_grid1(temporada);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_img_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		
		listview2.setOnTouchListener(new View.OnTouchListener() {
			    @Override
			    public boolean onTouch(View v, MotionEvent event) {
				        v.getParent().requestDisallowInterceptTouchEvent(true);
				        return false;
				    }
		});
		
		obterInfor.startRequestNetwork(RequestNetworkController.GET, s.getString("dns", "").concat("/player_api.php?username=".concat(s.getString("usuario", "").concat("&password=".concat(s.getString("senha", "").concat("&action=get_series_info&series_id="))))).concat(getIntent().getStringExtra("series_id")), "", _obterInfor_request_listener);
		streamid = getIntent().getStringExtra("series_id");
	}
	
	
	@Override
	public void onBackPressed() {
		vs.putExtra("ver", getIntent().getStringExtra("ver"));
		vs.putExtra("category_name", getIntent().getStringExtra("category_name"));
		vs.putExtra("category_id", getIntent().getStringExtra("category_id"));
		vs.setClass(getApplicationContext(), SeriesActivity.class);
		startActivity(vs);
		finish();
	}
	public void _tempo() {
		mm = new Gson().fromJson(FileUtil.readFile(FileUtil.getExternalStorageDir().concat("/teste/teste.json")), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		listview2.setAdapter(new Listview2Adapter(mm));
		((BaseAdapter)listview2.getAdapter()).notifyDataSetChanged();
	}
	
	
	public void _grid1(final ArrayList<HashMap<String, Object>> _listmap) {
		GridView gridView = new GridView(this); // Cria uma nova instância de GridView
		
		// Define os parâmetros de layout do GridView
		gridView.setLayoutParams(new GridView.LayoutParams(_listmap.size() * (int) getDip(153), GridLayout.LayoutParams.WRAP_CONTENT));
		gridView.setBackgroundColor(Color.TRANSPARENT); // Define a cor de fundo como transparente
		
		// Configurações adicionais do GridView
		gridView.setNumColumns(_listmap.size()); // Define o número de colunas com base no tamanho da lista
		gridView.setColumnWidth(GridView.AUTO_FIT); // Ajusta a largura das colunas automaticamente
		gridView.setVerticalSpacing(0); // Define o espaçamento vertical entre as linhas
		gridView.setHorizontalSpacing(0); // Define o espaçamento horizontal entre as colunas
		gridView.setStretchMode(GridView.STRETCH_COLUMN_WIDTH); // Estica as colunas para ocupar todo o espaço disponível
		gridView.invalidateViews(); // Invalida as views para forçar uma nova renderização
		
		// Define o adapter para o GridView
		gridView.setAdapter(new Listview1Adapter(_listmap)); // Substitua por seu adapter personalizado
		
		// Notifica que os dados do adapter mudaram
		((BaseAdapter) gridView.getAdapter()).notifyDataSetChanged();
		
		// Remove todas as views de linear_g1 e adiciona o GridView
		linear_g1.removeAllViews();
		linear_g1.addView(gridView);
		
		// Adiciona um listener para capturar cliques nos itens do GridView e mostrar a posição
		gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			    @Override
			    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				        // Exibe a posição do item clicado
				        
				// Inicializa a List<Map<String, Object>> para armazenar os episódios
				List<Map<String, Object>> listaEpisodio = new ArrayList<>();
				
				// Obtém o mapa de temporadas do objeto dataMap
				Map<String, Object> episodesMap = (Map<String, Object>) dataMap.get("episodes");
				
				// Acessa a lista de episódios da Temporada 1
				List<Map<String, Object>> episodiosDaTemporada1 = (List<Map<String, Object>>) episodesMap.get(posicaoTemporada1);
				
				// Itera sobre os episódios da Temporada 1
				for (Map<String, Object> episodio : episodiosDaTemporada1) {
					    // Cria um novo Map para armazenar as informações de cada episódio
					    Map<String, Object> episodioMap = new HashMap<>();
					
					    // Obtém os valores das chaves
					    String id2 = (String) episodio.get("id");
					    String episodeNum = (String) episodio.get("episode_num");
					    String title = (String) episodio.get("title");
					    String containerExtension = (String) episodio.get("container_extension");
					    
					    // Obtém informações adicionais do mapa 'info'
					    Map<String, Object> infoMap = (Map<String, Object>) episodio.get("info");
					    String plot = (String) infoMap.get("plot");
					    String duration = (String) infoMap.get("duration");
					    
					
					    // Armazena as informações no Map
					    episodioMap.put("id", id2);
					    episodioMap.put("episode_num", episodeNum);
					    episodioMap.put("title", title);
					    episodioMap.put("container_extension", containerExtension);
					    episodioMap.put("plot", plot);
					    episodioMap.put("duration", duration);
					    
					
					    // Adiciona o Map à lista
					    listaEpisodio.add(episodioMap);
				}
				
				// Exibe os itens armazenados em listaEpisodio
				for (Map<String, Object> episodio : listaEpisodio) {
					    System.out.println("ID: " + episodio.get("id2"));
					    System.out.println("Episódio: " + episodio.get("episode_num"));
					    System.out.println("Título: " + episodio.get("title"));
					    System.out.println("Extensão do arquivo: " + episodio.get("container_extension"));
					    System.out.println("Duração: " + episodio.get("duration"));
					    System.out.println("Enredo: " + episodio.get("plot"));
					    
					    System.out.println("----------------------------");
				}
				
				FileUtil.writeFile(FileUtil.getExternalStorageDir().concat("/teste/teste.json"), new Gson().toJson(listaEpisodio));
				finish();
				
				    }
		});
		
	}
	
	public class Listview2Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview2Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.episodios, null);
			}
			
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			
			imageview1.setImageResource(R.drawable.ic_play_circle_fill_whitet);
			textview1.setText(_data.get((int)_position).get("title").toString());
			if (_data.get((int)_position).containsKey("plot")) {
				textview2.setText(_data.get((int)_position).get("plot").toString());
			}
			else {
				textview2.setText("");
			}
			if (_data.get((int)_position).containsKey("movie_image")) {
				Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("movie_image").toString())).into(imageview1);
			}
			else {
				imageview1.setImageResource(R.drawable.piy);
			}
			
			return _view;
		}
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.temporadas, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			
			
			linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)5, (int)1, 0xFF424242, 0xFF212121));
			textview1.setText(_data.get((int)_position).get("posicao").toString().concat(" Temporada"));
			if (posicaoTemporada1.equals("")) {
				posicaoTemporada1 = _data.get((int)_position).get("posicao").toString();
				// Inicializa a List<Map<String, Object>> para armazenar os episódios
				List<Map<String, Object>> listaEpisodio = new ArrayList<>();
				
				// Obtém o mapa de temporadas do objeto dataMap
				Map<String, Object> episodesMap = (Map<String, Object>) dataMap.get("episodes");
				
				// Acessa a lista de episódios da Temporada 1
				List<Map<String, Object>> episodiosDaTemporada1 = (List<Map<String, Object>>) episodesMap.get(posicaoTemporada1);
				
				// Itera sobre os episódios da Temporada 1
				for (Map<String, Object> episodio : episodiosDaTemporada1) {
					    // Cria um novo Map para armazenar as informações de cada episódio
					    Map<String, Object> episodioMap = new HashMap<>();
					
					    // Obtém os valores das chaves
					    String id = (String) episodio.get("id");
					    String episodeNum = (String) episodio.get("episode_num");
					    String title = (String) episodio.get("title");
					    String containerExtension = (String) episodio.get("container_extension");
					    
					    // Obtém informações adicionais do mapa 'info'
					    Map<String, Object> infoMap = (Map<String, Object>) episodio.get("info");
					    String plot = (String) infoMap.get("plot");
					    String duration = (String) infoMap.get("duration");
					
					    // Armazena as informações no Map
					    episodioMap.put("id", id);
					    episodioMap.put("episode_num", episodeNum);
					    episodioMap.put("title", title);
					    episodioMap.put("container_extension", containerExtension);
					    episodioMap.put("plot", plot);
					    episodioMap.put("duration", duration);
					
					    // Adiciona o Map à lista
					    listaEpisodio.add(episodioMap);
				}
				
				// Exibe os itens armazenados em listaEpisodio
				for (Map<String, Object> episodio : listaEpisodio) {
					    System.out.println("ID: " + episodio.get("id"));
					    System.out.println("Episódio: " + episodio.get("episode_num"));
					    System.out.println("Título: " + episodio.get("title"));
					    System.out.println("Extensão do arquivo: " + episodio.get("container_extension"));
					    System.out.println("Duração: " + episodio.get("duration"));
					    System.out.println("Enredo: " + episodio.get("plot"));
					    System.out.println("----------------------------");
				}
				
				FileUtil.writeFile(FileUtil.getExternalStorageDir().concat("/teste/teste.json"), new Gson().toJson(listaEpisodio));
				_tempo();
			}
			else {
				// Inicializa a List<Map<String, Object>> para armazenar os episódios
				List<Map<String, Object>> listaEpisodio = new ArrayList<>();
				
				// Obtém o mapa de temporadas do objeto dataMap
				Map<String, Object> episodesMap = (Map<String, Object>) dataMap.get("episodes");
				
				// Acessa a lista de episódios da Temporada 1
				List<Map<String, Object>> episodiosDaTemporada1 = (List<Map<String, Object>>) episodesMap.get(posicaoTemporada1);
				
				// Itera sobre os episódios da Temporada 1
				for (Map<String, Object> episodio : episodiosDaTemporada1) {
					    // Cria um novo Map para armazenar as informações de cada episódio
					    Map<String, Object> episodioMap = new HashMap<>();
					
					    // Obtém os valores das chaves
					    String id = (String) episodio.get("id");
					    String episodeNum = (String) episodio.get("episode_num");
					    String title = (String) episodio.get("title");
					    String containerExtension = (String) episodio.get("container_extension");
					    
					    // Obtém informações adicionais do mapa 'info'
					    Map<String, Object> infoMap = (Map<String, Object>) episodio.get("info");
					    String plot = (String) infoMap.get("plot");
					    String duration = (String) infoMap.get("duration");
					
					    // Armazena as informações no Map
					    episodioMap.put("id", id);
					    episodioMap.put("episode_num", episodeNum);
					    episodioMap.put("title", title);
					    episodioMap.put("container_extension", containerExtension);
					    episodioMap.put("plot", plot);
					    episodioMap.put("duration", duration);
					
					    // Adiciona o Map à lista
					    listaEpisodio.add(episodioMap);
				}
				
				// Exibe os itens armazenados em listaEpisodio
				for (Map<String, Object> episodio : listaEpisodio) {
					    System.out.println("ID: " + episodio.get("id"));
					    System.out.println("Episódio: " + episodio.get("episode_num"));
					    System.out.println("Título: " + episodio.get("title"));
					    System.out.println("Extensão do arquivo: " + episodio.get("container_extension"));
					    System.out.println("Duração: " + episodio.get("duration"));
					    System.out.println("Enredo: " + episodio.get("plot"));
					    System.out.println("----------------------------");
				}
				
				FileUtil.writeFile(FileUtil.getExternalStorageDir().concat("/teste/teste.json"), new Gson().toJson(listaEpisodio));
				_tempo();
			}
			textview1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					posicaoTemporada1 = _data.get((int)_position).get("posicao").toString();
					// Inicializa a List<Map<String, Object>> para armazenar os episódios
					List<Map<String, Object>> listaEpisodio = new ArrayList<>();
					
					// Obtém o mapa de temporadas do objeto dataMap
					Map<String, Object> episodesMap = (Map<String, Object>) dataMap.get("episodes");
					
					// Acessa a lista de episódios da Temporada 1
					List<Map<String, Object>> episodiosDaTemporada1 = (List<Map<String, Object>>) episodesMap.get(posicaoTemporada1);
					
					// Itera sobre os episódios da Temporada 1
					for (Map<String, Object> episodio : episodiosDaTemporada1) {
						    // Cria um novo Map para armazenar as informações de cada episódio
						    Map<String, Object> episodioMap = new HashMap<>();
						
						    // Obtém os valores das chaves
						    String id = (String) episodio.get("id");
						    String episodeNum = (String) episodio.get("episode_num");
						    String title = (String) episodio.get("title");
						    String containerExtension = (String) episodio.get("container_extension");
						    
						    // Obtém informações adicionais do mapa 'info'
						    Map<String, Object> infoMap = (Map<String, Object>) episodio.get("info");
						    String plot = (String) infoMap.get("plot");
						    String duration = (String) infoMap.get("duration");
						
						    // Armazena as informações no Map
						    episodioMap.put("id", id);
						    episodioMap.put("episode_num", episodeNum);
						    episodioMap.put("title", title);
						    episodioMap.put("container_extension", containerExtension);
						    episodioMap.put("plot", plot);
						    episodioMap.put("duration", duration);
						
						    // Adiciona o Map à lista
						    listaEpisodio.add(episodioMap);
					}
					
					// Exibe os itens armazenados em listaEpisodio
					for (Map<String, Object> episodio : listaEpisodio) {
						    System.out.println("ID: " + episodio.get("id"));
						    System.out.println("Episódio: " + episodio.get("episode_num"));
						    System.out.println("Título: " + episodio.get("title"));
						    System.out.println("Extensão do arquivo: " + episodio.get("container_extension"));
						    System.out.println("Duração: " + episodio.get("duration"));
						    System.out.println("Enredo: " + episodio.get("plot"));
						    System.out.println("----------------------------");
					}
					
					FileUtil.writeFile(FileUtil.getExternalStorageDir().concat("/teste/teste.json"), new Gson().toJson(listaEpisodio));
					_tempo();
				}
			});
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					posicaoTemporada1 = _data.get((int)_position).get("posicao").toString();
					// Inicializa a List<Map<String, Object>> para armazenar os episódios
					List<Map<String, Object>> listaEpisodio = new ArrayList<>();
					
					// Obtém o mapa de temporadas do objeto dataMap
					Map<String, Object> episodesMap = (Map<String, Object>) dataMap.get("episodes");
					
					// Acessa a lista de episódios da Temporada 1
					List<Map<String, Object>> episodiosDaTemporada1 = (List<Map<String, Object>>) episodesMap.get(posicaoTemporada1);
					
					// Itera sobre os episódios da Temporada 1
					for (Map<String, Object> episodio : episodiosDaTemporada1) {
						    // Cria um novo Map para armazenar as informações de cada episódio
						    Map<String, Object> episodioMap = new HashMap<>();
						
						    // Obtém os valores das chaves
						    String id = (String) episodio.get("id");
						    String episodeNum = (String) episodio.get("episode_num");
						    String title = (String) episodio.get("title");
						    String containerExtension = (String) episodio.get("container_extension");
						    
						    // Obtém informações adicionais do mapa 'info'
						    Map<String, Object> infoMap = (Map<String, Object>) episodio.get("info");
						    String plot = (String) infoMap.get("plot");
						    String duration = (String) infoMap.get("duration");
						
						    // Armazena as informações no Map
						    episodioMap.put("id", id);
						    episodioMap.put("episode_num", episodeNum);
						    episodioMap.put("title", title);
						    episodioMap.put("container_extension", containerExtension);
						    episodioMap.put("plot", plot);
						    episodioMap.put("duration", duration);
						
						    // Adiciona o Map à lista
						    listaEpisodio.add(episodioMap);
					}
					
					// Exibe os itens armazenados em listaEpisodio
					for (Map<String, Object> episodio : listaEpisodio) {
						    System.out.println("ID: " + episodio.get("id"));
						    System.out.println("Episódio: " + episodio.get("episode_num"));
						    System.out.println("Título: " + episodio.get("title"));
						    System.out.println("Extensão do arquivo: " + episodio.get("container_extension"));
						    System.out.println("Duração: " + episodio.get("duration"));
						    System.out.println("Enredo: " + episodio.get("plot"));
						    System.out.println("----------------------------");
					}
					
					FileUtil.writeFile(FileUtil.getExternalStorageDir().concat("/teste/teste.json"), new Gson().toJson(listaEpisodio));
					_tempo();
				}
			});
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}