package com.sr.systems.iptv;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import android.provider.Settings;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.util.HashMap;
import java.util.Map;

// Import necessário para UiModeManager
import android.app.UiModeManager;
import android.content.res.Configuration;
import android.content.pm.ActivityInfo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.util.Log;


public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private double p = 0;
	private String token = "";
	private String getMac = "";
	private HashMap<String, Object> maps = new HashMap<>();
	private String getUser = "";
	private String getDns = "";
	private String getSejnha = "";
	private HashMap<String, Object> DadosUser = new HashMap<>();
	private HashMap<String, Object> dados = new HashMap<>();
	private HashMap<String, Object> userInfo = new HashMap<>();
	private HashMap<String, Object> userInfoMap = new HashMap<>();
	private HashMap<String, Object> jsonMap = new HashMap<>();
	private String id_categorias_filmes = "";
	private double pp = 0;
	private HashMap<String, Object> m = new HashMap<>();
	private HashMap<String, Object> cabecalho = new HashMap<>();
	private HashMap<String, Object> getInfoPanel = new HashMap<>();
	private String usuario = "";
	private String senha = "";
	private String jsonString = "";
	private String mensagem = "";
	private HashMap<String, Object> dns = new HashMap<>();
	private String painel = "";
	private String getUrl = "";
	
	private ArrayList<HashMap<String, Object>> mp = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> carregarMais = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> us = new ArrayList<>();
	
	private LinearLayout linear1;
	private ImageView imageview2;
	private ImageView loading;
	private TextView mac;
	private TextView textView1;
	private TextView textview1;
	private TextView textview2;
	private EditText edittext1;
	private TextView textview3;
	private TextView textview4;
	private TextView gets;
	
	private TimerTask t;
	private RequestNetwork categoria_serie;
	private RequestNetwork.RequestListener _categoria_serie_request_listener;
	private RequestNetwork lancamentos;
	private RequestNetwork.RequestListener _lancamentos_request_listener;
	private RequestNetwork serie;
	private RequestNetwork.RequestListener _serie_request_listener;
	private RequestNetwork categoria_canais;
	private RequestNetwork.RequestListener _categoria_canais_request_listener;
	private RequestNetwork categoria_filmes;
	private RequestNetwork.RequestListener _categoria_filmes_request_listener;
	private Intent ir = new Intent();
	private DatabaseReference iptv = _firebase.getReference("iptv");
	private ChildEventListener _iptv_child_listener;
	private RequestNetwork user;
	private RequestNetwork.RequestListener _user_request_listener;
	private SharedPreferences s;
	private Calendar c = Calendar.getInstance();
	private DatabaseReference painel_teste = _firebase.getReference("painel_teste");
	private ChildEventListener _painel_teste_child_listener;
	private RequestNetwork getDataOffice;
	private RequestNetwork.RequestListener _getDataOffice_request_listener;
	private RequestNetwork getDataOpanel;
	private RequestNetwork.RequestListener _getDataOpanel_request_listener;
	private TimerTask tt;
	private SharedPreferences dataExpiracao;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		
		// Obter o UiModeManager
		UiModeManager uiModeManager = (UiModeManager) getSystemService(UI_MODE_SERVICE);
		
		// Verificar se é um celular
		if (uiModeManager.getCurrentModeType() == Configuration.UI_MODE_TYPE_NORMAL) {
				    // É um celular, definir a orientação para vertical
				    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		} else {
				    // Não é um celular (pode ser tablet ou TV), definir a orientação para horizontal
				    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		}
		
		linear1 = findViewById(R.id.linear1);
		imageview2 = findViewById(R.id.imageview2);
		loading = findViewById(R.id.loading);
		mac = findViewById(R.id.mac);
		textView1 = findViewById(R.id.textView1);
		textview1 = findViewById(R.id.textview1);
		textview2 = findViewById(R.id.textview2);
		edittext1 = findViewById(R.id.edittext1);
		textview3 = findViewById(R.id.textview3);
		textview4 = findViewById(R.id.textview4);
		gets = findViewById(R.id.gets);
		categoria_serie = new RequestNetwork(this);
		lancamentos = new RequestNetwork(this);
		serie = new RequestNetwork(this);
		categoria_canais = new RequestNetwork(this);
		categoria_filmes = new RequestNetwork(this);
		user = new RequestNetwork(this);
		s = getSharedPreferences("s", Activity.MODE_PRIVATE);
		getDataOffice = new RequestNetwork(this);
		getDataOpanel = new RequestNetwork(this);
		dataExpiracao = getSharedPreferences("dataExpiracao", Activity.MODE_PRIVATE);
		
		textview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", textview1.getText().toString()));
			}
		});
		
		textview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", textview2.getText().toString()));
			}
		});
		
		textview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", textview3.getText().toString()));
			}
		});
		
		textview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", textview4.getText().toString()));
			}
		});
		
		_categoria_serie_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
				FileUtil.writeFile(FileUtil.getExternalStorageDir().concat("/serie/categoria/categoria.json"), _response);
				serie.startRequestNetwork(RequestNetworkController.GET, getDns.concat("/player_api.php?username=".concat(getUser.concat("&password=".concat(getSejnha.concat("&action=get_series"))))), "seirie", _serie_request_listener);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_lancamentos_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				FileUtil.writeFile(FileUtil.getExternalStorageDir().concat("/serie/categoria/lancamento.json"), _response);
				s.edit().putString("dns", getDns).commit();
				s.edit().putString("usuario", getUser).commit();
				s.edit().putString("senha", getSejnha).commit();
				ir.setClass(getApplicationContext(), HomeActivity.class);
				startActivity(ir);
				finish();
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_serie_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
				FileUtil.writeFile(FileUtil.getExternalStorageDir().concat("/serie/serie.json"), _response);
				categoria_canais.startRequestNetwork(RequestNetworkController.GET, getDns.concat("/player_api.php?username=".concat(getUser.concat("&password=".concat(getSejnha.concat("&action=get_live_categories"))))), "canais", _categoria_canais_request_listener);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_categoria_canais_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				FileUtil.writeFile(FileUtil.getExternalStorageDir().concat("/serie/categoria/canais.json"), _response);
				categoria_filmes.startRequestNetwork(RequestNetworkController.GET, getDns.concat("/player_api.php?username=".concat(getUser.concat("&password=".concat(getSejnha.concat("&action=get_vod_categories"))))), "", _categoria_filmes_request_listener);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_categoria_filmes_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				FileUtil.writeFile(FileUtil.getExternalStorageDir().concat("/serie/categoria/filmes.json"), _response);
				carregarMais = new Gson().fromJson(FileUtil.readFile(FileUtil.getExternalStorageDir().concat("/serie/categoria/filmes.json")), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				p = 0;
				for(int _repeat30 = 0; _repeat30 < (int)(carregarMais.size()); _repeat30++) {
					if (carregarMais.get((int)p).get("category_name").toString().contains(new SimpleDateFormat("yyyy").format(c.getTime()))) {
						id_categorias_filmes = carregarMais.get((int)p).get("category_id").toString();
					}
					else {
						p++;
					}
				}
				lancamentos.startRequestNetwork(RequestNetworkController.GET, getDns.concat("/player_api.php?username=".concat(getUser.concat("&password=".concat(getSejnha.concat("&action=get_vod_streams&category_id=".concat(id_categorias_filmes)))))), "", _lancamentos_request_listener);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_iptv_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		iptv.addChildEventListener(_iptv_child_listener);
		
		_user_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", _response));
				if (_response.contains("html")) {
					SketchwareUtil.showMessage(getApplicationContext(), _response);
					FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/serie/"));
					ir.putExtra("url", getDns.concat("/player_api.php?username=".concat(getUser.concat("&password=".concat(getSejnha.concat(""))))));
					ir.putExtra("i", mensagem);
					ir.putExtra("mac", mac.getText().toString());
					ir.putExtra("ver", "criar");
					ir.setClass(getApplicationContext(), LoginActivity.class);
					startActivity(ir);
					finish();
				}
				else {
					if (_response.contains("error")) {
						SketchwareUtil.showMessage(getApplicationContext(), _response);
						FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/serie/"));
						ir.putExtra("url", getDns.concat("/player_api.php?username=".concat(getUser.concat("&password=".concat(getSejnha.concat(""))))));
						ir.putExtra("i", mensagem);
						ir.putExtra("mac", mac.getText().toString());
						ir.putExtra("ver", "criar");
						ir.setClass(getApplicationContext(), LoginActivity.class);
						startActivity(ir);
						finish();
					}
					else {
						if (_response.contains("invalid")) {
							ir.putExtra("i", mensagem);
							ir.putExtra("ver", "vencido");
							ir.putExtra("mac", mac.getText().toString());
							ir.setClass(getApplicationContext(), LoginActivity.class);
							startActivity(ir);
							finish();
						}
						else {
							// Usando Gson para converter JSON em Map
							Gson gson = new Gson();
							Map<String, Object> jsonMap = gson.fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
							
							// Obtendo o mapa 'user_info' e 'server_info'
							Map<String, Object> userInfoMap = (Map<String, Object>) jsonMap.get("user_info");
							Map<String, Object> serverInfoMap = (Map<String, Object>) jsonMap.get("server_info");
							
							// Extraindo valores de 'user_info'
							String username = (String) userInfoMap.get("username");
							String password = (String) userInfoMap.get("password");
							String status = (String) userInfoMap.get("status");
							String exp_date = (String ) userInfoMap.get ("exp_date");
							if (status.toUpperCase().equals("active".toUpperCase())) {
								dataExpiracao.edit().putString("data", exp_date).commit();
								categoria_serie.startRequestNetwork(RequestNetworkController.GET, getDns.concat("/player_api.php?username=".concat(getUser.concat("&password=".concat(getSejnha.concat("&action=get_series_categories"))))), "categoria", _categoria_serie_request_listener);
							}
							else {
								SketchwareUtil.showMessage(getApplicationContext(), _response);
								FileUtil.deleteFile(FileUtil.getExternalStorageDir().concat("/serie/"));
								ir.putExtra("i", mensagem);
								ir.putExtra("ver", "vencido");
								ir.putExtra("mac", mac.getText().toString());
								ir.setClass(getApplicationContext(), LoginActivity.class);
								startActivity(ir);
								finish();
							}
						}
					}
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_painel_teste_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		painel_teste.addChildEventListener(_painel_teste_child_listener);
		
		_getDataOffice_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				if (_response.contains("html")) {
					ir.putExtra("i", mensagem);
					ir.putExtra("mac", mac.getText().toString());
					ir.putExtra("ver", "falha");
					ir.setClass(getApplicationContext(), LoginActivity.class);
					startActivity(ir);
					finish();
				}
				else {
					// Primeiro, obtenha a mensagem do JSON
					String jsonResponse = _response;
					String message = jsonResponse.split("\"message\":\"")[1].split("\"")[0].replace("\\r\\n", "\n");
					
					// Agora, extraia o usuário e a senha da mensagem
					String usuario = message.split("Usuario: ")[1].split("\n")[0].trim();
					String senha = message.split("Senha: ")[1].split("\n")[0].trim();
					
					textview3.setText(usuario);
					textview4.setText(senha);
					maps = new HashMap<>();
					maps.put("mac", mac.getText().toString());
					maps.put("usuario", textview3.getText().toString());
					maps.put("senha", textview4.getText().toString());
					maps.put("verificar", "true");
					maps.put("nome", "alterar");
					maps.put("dns", getDns);
					mensagem = "Seu usuário ainda está sendo gerado por favor  e aguarde";
					iptv.child(mac.getText().toString()).updateChildren(maps);
					user.startRequestNetwork(RequestNetworkController.GET, getDns.concat("/player_api.php?username=".concat(getUser.concat("&password=".concat(getSejnha.concat(""))))), "g", _user_request_listener);
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_getDataOpanel_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", _response));
				if (_response.contains("html")) {
					ir.putExtra("i", mensagem);
					ir.putExtra("mac", mac.getText().toString());
					ir.putExtra("ver", "falha");
					ir.setClass(getApplicationContext(), LoginActivity.class);
					startActivity(ir);
					finish();
				}
				else {
					
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		String androidId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
		
		
		token = androidId;
		StringBuilder formattedToken = new StringBuilder();
		
		for (int i = 0; i < token.length(); i++) {
			    if (i > 0 && i % 2 == 0) {
				        formattedToken.append(":");
				    }
			    formattedToken.append(token.charAt(i));
		}
		
		textView1.setText(formattedToken.toString());
		
		mac.setText(textView1.getText().toString());
		
		t = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						p = p + 50;
						loading.setRotation((float)(p));
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(t, (int)(0), (int)(100));
		painel_teste.addListenerForSingleValueEvent(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot _dataSnapshot) {
				us = new ArrayList<>();
				try {
					GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
					for (DataSnapshot _data : _dataSnapshot.getChildren()) {
						HashMap<String, Object> _map = _data.getValue(_ind);
						us.add(_map);
					}
				}
				catch (Exception _e) {
					_e.printStackTrace();
				}
				pp = 0;
				for(int _repeat198 = 0; _repeat198 < (int)(us.size()); _repeat198++) {
					getDns = us.get((int)pp).get("dns").toString();
					painel = us.get((int)pp).get("painel").toString();
					getUrl = us.get((int)pp).get("url").toString();
					SketchwareUtil.showMessage(getApplicationContext(), us.get((int)pp).get("dns").toString());
					pp++;
				}
				com.google.firebase.database.Query query = iptv.orderByChild("verificar").equalTo(("true")); 
				
				ValueEventListener valueEventListener = new ValueEventListener() { @Override public void onDataChange(DataSnapshot dataSnapshot) { try { mp = new ArrayList<>();
							
							 GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {}; for (DataSnapshot _data : dataSnapshot.getChildren()) { HashMap<String, Object> _map = _data.getValue(_ind); 
								mp.add(_map); } 
							p = 0;
							for(int _repeat222 = 0; _repeat222 < (int)(mp.size()); _repeat222++) {
								if (mac.getText().toString().contains(mp.get((int)p).get("mac").toString())) {
									getMac = mp.get((int)p).get("mac").toString();
									getUser = mp.get((int)p).get("usuario").toString();
									getSejnha = mp.get((int)p).get("senha").toString();
									getDns = mp.get((int)p).get("dns").toString();
									mensagem = "existe";
								}
								else {
									p++;
								}
							}
							if (mensagem.equals("")) {
								if (painel.toUpperCase().equals("Office".toUpperCase())) {
									cabecalho = new HashMap<>();
									cabecalho.put("Content-Type", "application/json");
									m = new HashMap<>();
									m.put("groupName", "grupo");
									m.put("isMessageFromGroup", "false");
									m.put("messageDataTime", String.valueOf((long)(c.getTimeInMillis())));
									m.put("receiveMessageAppId", "com.whatsapp");
									m.put("receiveMessagePattern", "teste");
									m.put("senderMessage", "teste");
									m.put("senderName", "usuário");
									SketchwareUtil.showMessage(getApplicationContext(), "Criando Koffce");
									getDataOffice.setHeaders(cabecalho);
									getDataOffice.setParams(m, RequestNetworkController.REQUEST_BODY);
									getDataOffice.startRequestNetwork(RequestNetworkController.POST, getUrl, "t", _getDataOffice_request_listener);
								}
								else {
									cabecalho = new HashMap<>();
									cabecalho.put("Content-Type", "application/json");
									m = new HashMap<>();
									m.put("groupName", "grupo");
									m.put("isMessageFromGroup", "false");
									m.put("messageDataTime", String.valueOf((long)(c.getTimeInMillis())));
									m.put("receiveMessageAppId", "com.whatsapp");
									m.put("receiveMessagePattern", "teste");
									m.put("senderMessage", "teste");
									m.put("senderName", "usuário");
									SketchwareUtil.showMessage(getApplicationContext(), "criando Qpanel");
									getDataOpanel.setHeaders(cabecalho);
									getDataOpanel.setParams(m, RequestNetworkController.REQUEST_BODY);
									getDataOpanel.startRequestNetwork(RequestNetworkController.POST, getUrl, "t", _getDataOpanel_request_listener);
								}
							}
							else {
								SketchwareUtil.showMessage(getApplicationContext(), "pegando dados usuários");
								user.startRequestNetwork(RequestNetworkController.GET, getDns.concat("/player_api.php?username=".concat(getUser.concat("&password=".concat(getSejnha.concat(""))))), "g", _user_request_listener);
							}
							//lisview adapter listmap 
							//listview att
							
						} catch (Exception e) { e.printStackTrace(); } } 
					
					@Override public void onCancelled(DatabaseError databaseError) { } }; query.addValueEventListener(valueEventListener);
			}
			@Override
			public void onCancelled(DatabaseError _databaseError) {
			}
		});
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}