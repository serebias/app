package com.sr.systems.iptv;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bumptech.glide.Glide;
import com.google.firebase.FirebaseApp;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
// Import necessário para UiModeManager
import android.app.UiModeManager;
import android.content.res.Configuration;
import android.content.pm.ActivityInfo;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
// Adicione este código em um bloco de código Java no Sketchware
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.widget.Toast;
import java.util.List;

public class EspecificaoActivity extends AppCompatActivity {
	
	private HashMap<String, Object> map = new HashMap<>();
	private double p = 0;
	private HashMap<String, Object> info = new HashMap<>();
	private HashMap<String, Object> moveData = new HashMap<>();
	private String jsonString = "";
	private HashMap<String, Object> movieDataMap = new HashMap<>();
	private HashMap<String, Object> infoMap = new HashMap<>();
	private String url = "";
	private HashMap<String, Object> o = new HashMap<>();
	private String stream_id = "";
	
	private ArrayList<HashMap<String, Object>> list = new ArrayList<>();
	
	private LinearLayout linear1;
	private TextView textview2;
	private ImageView imageview1;
	private LinearLayout linear2;
	private TextView descrition;
	private LinearLayout play;
	private TextView duratio;
	private TextView nome;
	private LinearLayout linear3;
	private TextView avaliacao;
	private ImageView imageview2;
	private TextView dta;
	private TextView textview1;
	private ImageView imageview3;
	
	private RequestNetwork obterInfo;
	private RequestNetwork.RequestListener _obterInfo_request_listener;
	private Intent volt = new Intent();
	private Intent ir = new Intent();
	private SharedPreferences s;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.especificao);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		
		// Obter o UiModeManager
		UiModeManager uiModeManager = (UiModeManager) getSystemService(UI_MODE_SERVICE);
		
		// Verificar se é um celular
		if (uiModeManager.getCurrentModeType() == Configuration.UI_MODE_TYPE_NORMAL) {
				    // É um celular, definir a orientação para vertical
				    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		} else {
				    // Não é um celular (pode ser tablet ou TV), definir a orientação para horizontal
				    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		}
		
		linear1 = findViewById(R.id.linear1);
		textview2 = findViewById(R.id.textview2);
		imageview1 = findViewById(R.id.imageview1);
		linear2 = findViewById(R.id.linear2);
		descrition = findViewById(R.id.descrition);
		play = findViewById(R.id.play);
		duratio = findViewById(R.id.duratio);
		nome = findViewById(R.id.nome);
		linear3 = findViewById(R.id.linear3);
		avaliacao = findViewById(R.id.avaliacao);
		imageview2 = findViewById(R.id.imageview2);
		dta = findViewById(R.id.dta);
		textview1 = findViewById(R.id.textview1);
		imageview3 = findViewById(R.id.imageview3);
		obterInfo = new RequestNetwork(this);
		s = getSharedPreferences("s", Activity.MODE_PRIVATE);
		
		play.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				url = s.getString("dns", "").concat("/movie/".concat(s.getString("usuario", "").concat("/".concat(s.getString("senha", "").concat("/".concat(textview2.getText().toString().concat(".mp4")))))));
				
				    // Verifica se o VLC está instalado
				    PackageManager packageManager = getPackageManager();
				    Intent intent = new Intent(Intent.ACTION_VIEW);
				    intent.setDataAndType(Uri.parse(url), "video/*");
				    List<ResolveInfo> resolveInfoList = packageManager.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
				
				    boolean vlcInstalled = false;
				    for (ResolveInfo resolveInfo : resolveInfoList) {
					        if (resolveInfo.activityInfo.packageName.equals("org.videolan.vlc")) {
						            vlcInstalled = true;
						            break;
						        }
					    }
				
				    if (vlcInstalled) {
					        // Cria uma Intent para abrir o VLC com a URL
					        Intent vlcIntent = new Intent(Intent.ACTION_VIEW);
					        vlcIntent.setDataAndType(Uri.parse(url), "video/*");
					        vlcIntent.setPackage("org.videolan.vlc");
					        startActivity(vlcIntent);
					    } else {
					        // Solicita ao usuário que baixe o VLC
					         
					        Intent playStoreIntent = new Intent(Intent.ACTION_VIEW);
					        playStoreIntent.setData(Uri.parse("market://details?id=org.videolan.vlc"));
					        startActivity(playStoreIntent);
					    }
				
			}
		});
		
		_obterInfo_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", _response));
				imageview2.setVisibility(View.VISIBLE);
				jsonString = _response;
				// Usando Gson para converter JSON em Map
				Gson gson = new Gson();
				Map<String, Object> jsonMap = gson.fromJson(jsonString, new TypeToken<HashMap<String, Object>>(){}.getType());
				
				// Obtendo o mapa 'info' e 'movie_data'
				Map<String, Object> infoMap = (Map<String, Object>) jsonMap.get("info");
				Map<String, Object> movieDataMap = (Map<String, Object>) jsonMap.get("movie_data");
				
				// Verifica se as chaves no 'infoMap' existem, se não, cria com valor "vazio"
				if (!infoMap.containsKey("tmdb_url")) {
					    infoMap.put("tmdb_url", "vazio");
				}
				if (!infoMap.containsKey("name")) {
					    infoMap.put("name", "vazio");
				}
				if (!infoMap.containsKey("movie_image")) {
					    infoMap.put("movie_image", "vazio");
				}
				if (!infoMap.containsKey("description")) {
					    infoMap.put("description", "vazio");
				}
				if (!infoMap.containsKey("rating")) {
					    infoMap.put("rating", "vazio");
				}
				if (!infoMap.containsKey("duration")) {
					    infoMap.put("duration", "vazio");
				}
				if (!infoMap.containsKey("release_date")) {
					    infoMap.put("release_date", "vazio");
				}
				if (!infoMap.containsKey("backdrop_path")) {
					    infoMap.put("backdrop_path", new ArrayList<String>()); // Cria uma lista vazia se não existir
				}
				
				// Verifica se as chaves no 'movieDataMap' existem, se não, cria com valor "vazio"
				if (!movieDataMap.containsKey("container_extension")) {
					    movieDataMap.put("container_extension", "vazio");
				}
				
				// Extraindo valores após garantir a existência das chaves
				String tmdbUrl = (String) infoMap.get("tmdb_url");
				String name = (String) infoMap.get("name");
				String movieImage = (String) infoMap.get("movie_image");
				String description = (String) infoMap.get("description");
				
				// Pegando o primeiro item da lista 'backdrop_path' e colocando de volta no map
				List<String> backdropPathList = (List<String>) infoMap.get("backdrop_path");
				if (backdropPathList != null && !backdropPathList.isEmpty()) {
					    infoMap.put("backdrop_path", backdropPathList.get(0)); // Atualiza o mapa com o primeiro item da lista
				} else {
					    infoMap.put("backdrop_path", "vazio"); // Se a lista estiver vazia ou for nula, define como "vazio"
				}
				
				String rating = String.valueOf(infoMap.get("rating")); // Converte para String
				String duration = (String) infoMap.get("duration");
				String releaseDate = (String) infoMap.get("release_date");
				String containerExtension = (String) movieDataMap.get("container_extension");
				
				if (infoMap.get("backdrop_path").toString().equals("vazio")) {
					imageview1.setImageResource(R.drawable.piy);
				}
				else {
					Glide.with(getApplicationContext()).load(Uri.parse(infoMap.get("backdrop_path").toString())).into(imageview1);
				}
				nome.setText(infoMap.get("name").toString());
				avaliacao.setText("Avaliação ".concat(infoMap.get("rating").toString()));
				descrition.setText(infoMap.get("description").toString());
				play.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)50, (int)0, Color.TRANSPARENT, 0xFFBB9B5B));
				dta.setText("Data Adicionada : ".concat(infoMap.get("release_date").toString()));
				duratio.setText("Duração : ".concat(infoMap.get("duration").toString()));
				textview2.setText(String.valueOf((long)(Double.parseDouble(getIntent().getStringExtra("stream_id")))));
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		
		imageview2.setVisibility(View.GONE);
		obterInfo.startRequestNetwork(RequestNetworkController.GET, s.getString("dns", "").concat("/player_api.php?username=".concat(s.getString("usuario", "").concat("&password=".concat(s.getString("senha", "").concat("&action=get_vod_info&vod_id=").concat(getIntent().getStringExtra("stream_id")))))), "", _obterInfo_request_listener);
		stream_id = getIntent().getStringExtra("stream_id");
	}
	
	
	@Override
	public void onBackPressed() {
		if (getIntent().getStringExtra("voltar").equals("home")) {
			ir.setClass(getApplicationContext(), HomeActivity.class);
			startActivity(ir);
			finish();
		}
		else {
			ir.putExtra("voltar", getIntent().getStringExtra("voltar"));
			ir.putExtra("category_id", getIntent().getStringExtra("category_id"));
			ir.putExtra("category_name", getIntent().getStringExtra("category_name"));
			ir.putExtra("ver", getIntent().getStringExtra("ver"));
			ir.putExtra("stream_id", getIntent().getStringExtra("stream_id"));
			ir.setClass(getApplicationContext(), CategoriaCanaisActivity.class);
			startActivity(ir);
			finish();
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}