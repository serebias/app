package com.sr.systems.iptv;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bumptech.glide.Glide;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
// Import necessário para UiModeManager
import android.app.UiModeManager;
import android.content.res.Configuration;
import android.content.pm.ActivityInfo;


public class HomeActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private double p0 = 0;
	private HashMap<String, Object> filmesChaves = new HashMap<>();
	private double expira = 0;
	
	private ArrayList<HashMap<String, Object>> MapLancamentos = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> canais_lista_categoria = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> categoriaSerie = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> categoriasFilmes = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> visibleLancamentos = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> melhor_avaliados = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> melhorAvaliadaos = new ArrayList<>();
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private TextView data;
	private LinearLayout linear21;
	private LinearLayout linear4;
	private LinearLayout linear3;
	private LinearLayout linear16;
	private LinearLayout linear19;
	private TextView lanca;
	private HorizontalScrollView hscroll1;
	private LinearLayout linear_g2;
	private ListView listview1;
	private LinearLayout linear15;
	private HorizontalScrollView hscroll2;
	private TextView textview13;
	private Button button1;
	private LinearLayout linear_g1;
	private ListView listview2;
	private LinearLayout linear17;
	private HorizontalScrollView hscroll5;
	private TextView textview;
	private Button button2;
	private LinearLayout linear_g5;
	private ListView listview5;
	private LinearLayout linear20;
	private HorizontalScrollView hscroll6;
	private TextView textView09;
	private Button button3;
	private LinearLayout linear_g6;
	private ListView listview6;
	
	private TimerTask c;
	private TimerTask c2;
	private TimerTask c3;
	private Intent it = new Intent();
	private AlertDialog.Builder d;
	private Calendar vc = Calendar.getInstance();
	private Calendar h = Calendar.getInstance();
	private SharedPreferences dataExpiracao;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.home);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		
		// Obter o UiModeManager
		UiModeManager uiModeManager = (UiModeManager) getSystemService(UI_MODE_SERVICE);
		
		// Verificar se é um celular
		if (uiModeManager.getCurrentModeType() == Configuration.UI_MODE_TYPE_NORMAL) {
				    // É um celular, definir a orientação para vertical
				    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		} else {
				    // Não é um celular (pode ser tablet ou TV), definir a orientação para horizontal
				    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		}
		
		vscroll1 = findViewById(R.id.vscroll1);
		linear1 = findViewById(R.id.linear1);
		data = findViewById(R.id.data);
		linear21 = findViewById(R.id.linear21);
		linear4 = findViewById(R.id.linear4);
		linear3 = findViewById(R.id.linear3);
		linear16 = findViewById(R.id.linear16);
		linear19 = findViewById(R.id.linear19);
		lanca = findViewById(R.id.lanca);
		hscroll1 = findViewById(R.id.hscroll1);
		linear_g2 = findViewById(R.id.linear_g2);
		listview1 = findViewById(R.id.listview1);
		linear15 = findViewById(R.id.linear15);
		hscroll2 = findViewById(R.id.hscroll2);
		textview13 = findViewById(R.id.textview13);
		button1 = findViewById(R.id.button1);
		linear_g1 = findViewById(R.id.linear_g1);
		listview2 = findViewById(R.id.listview2);
		linear17 = findViewById(R.id.linear17);
		hscroll5 = findViewById(R.id.hscroll5);
		textview = findViewById(R.id.textview);
		button2 = findViewById(R.id.button2);
		linear_g5 = findViewById(R.id.linear_g5);
		listview5 = findViewById(R.id.listview5);
		linear20 = findViewById(R.id.linear20);
		hscroll6 = findViewById(R.id.hscroll6);
		textView09 = findViewById(R.id.textView09);
		button3 = findViewById(R.id.button3);
		linear_g6 = findViewById(R.id.linear_g6);
		listview6 = findViewById(R.id.listview6);
		d = new AlertDialog.Builder(this);
		dataExpiracao = getSharedPreferences("dataExpiracao", Activity.MODE_PRIVATE);
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				it.putExtra("ver", "canais");
				it.setClass(getApplicationContext(), VermaisActivity.class);
				startActivity(it);
				finish();
			}
		});
		
		listview2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				it.putExtra("ver", "home");
				it.putExtra("voltar", "home");
				it.putExtra("category_name", canais_lista_categoria.get((int)_position).get("category_name").toString());
				it.putExtra("category_id", canais_lista_categoria.get((int)_position).get("category_id").toString());
				it.setClass(getApplicationContext(), CanaisActivity.class);
				startActivity(it);
				finish();
			}
		});
		
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				it.putExtra("ver", "filmes");
				it.setClass(getApplicationContext(), VermaisActivity.class);
				startActivity(it);
				finish();
			}
		});
		
		listview5.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				it.putExtra("ver", "home");
				it.putExtra("voltar", "home");
				it.putExtra("category_name", categoriasFilmes.get((int)_position).get("category_name").toString());
				it.putExtra("category_id", categoriasFilmes.get((int)_position).get("category_id").toString());
				it.setClass(getApplicationContext(), CategoriaCanaisActivity.class);
				startActivity(it);
				finish();
			}
		});
		
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				it.putExtra("ver", "series");
				it.setClass(getApplicationContext(), VermaisActivity.class);
				startActivity(it);
				finish();
			}
		});
		
		listview6.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				it.putExtra("ver", "home");
				it.putExtra("voltar", "home");
				it.putExtra("category_name", categoriaSerie.get((int)_position).get("category_name").toString());
				it.putExtra("category_id", categoriaSerie.get((int)_position).get("category_id").toString());
				it.setClass(getApplicationContext(), SeriesActivity.class);
				startActivity(it);
				finish();
			}
		});
	}
	
	private void initializeLogic() {
		expira = Double.parseDouble(dataExpiracao.getString("data", "")) * 1000;
		h.setTimeInMillis((long)(expira));
		data.setText("Sua lista expira em ".concat(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(h.getTime())));
		android.graphics.drawable.GradientDrawable HIFGDEJ = new android.graphics.drawable.GradientDrawable();
		HIFGDEJ.setColor(Color.parseColor("#FF000000"));
		HIFGDEJ.setCornerRadius(0);
		android.graphics.drawable.RippleDrawable HIFGDEJ_RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.parseColor("#FFFFEB3B")}), HIFGDEJ, null);
		button1.setBackground(HIFGDEJ_RE);
		android.graphics.drawable.GradientDrawable ECABJFF = new android.graphics.drawable.GradientDrawable();
		ECABJFF.setColor(Color.parseColor("#FF000000"));
		ECABJFF.setCornerRadius(0);
		android.graphics.drawable.RippleDrawable ECABJFF_RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.parseColor("#FFFFEB3B")}), ECABJFF, null);
		button2.setBackground(ECABJFF_RE);
		android.graphics.drawable.GradientDrawable FIGBAAF = new android.graphics.drawable.GradientDrawable();
		FIGBAAF.setColor(Color.parseColor("#FF000000"));
		FIGBAAF.setCornerRadius(0);
		android.graphics.drawable.RippleDrawable FIGBAAF_RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.parseColor("#FFFFEB3B")}), FIGBAAF, null);
		button3.setBackground(FIGBAAF_RE);
		listview1.setOnTouchListener(new View.OnTouchListener() {
			    @Override
			    public boolean onTouch(View v, MotionEvent event) {
				        v.getParent().requestDisallowInterceptTouchEvent(true);
				        return false;
				    }
		});
		
		listview2.setOnTouchListener(new View.OnTouchListener() {
			    @Override
			    public boolean onTouch(View v, MotionEvent event) {
				        v.getParent().requestDisallowInterceptTouchEvent(true);
				        return false;
				    }
		});
		
		listview5.setOnTouchListener(new View.OnTouchListener() {
			    @Override
			    public boolean onTouch(View v, MotionEvent event) {
				        v.getParent().requestDisallowInterceptTouchEvent(true);
				        return false;
				    }
		});
		
		listview6.setOnTouchListener(new View.OnTouchListener() {
			    @Override
			    public boolean onTouch(View v, MotionEvent event) {
				        v.getParent().requestDisallowInterceptTouchEvent(true);
				        return false;
				    }
		});
		
		
		MapLancamentos = new Gson().fromJson(FileUtil.readFile(FileUtil.getExternalStorageDir().concat("/serie/categoria/lancamento.json")), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		// Supondo que você já tenha carregado MapLancamentos e inicializado melhor_avaliados
		
		// Inicializa melhor_avaliados como uma lista
		ArrayList<HashMap<String, Object>> melhor_avaliados = new ArrayList<>();
		
		// Itera sobre MapLancamentos
		for (int i = 0; i < MapLancamentos.size(); i++) {
			    HashMap<String, Object> lancamento = MapLancamentos.get(i);
			
			    // Converte a classificação para um valor numérico
			    double rating;
			    try {
				        rating = Double.parseDouble(lancamento.get("rating").toString());
				    } catch (NumberFormatException e) {
				        continue; // Ignora se a classificação não for um número válido
				    }
			
			    // Adiciona ao melhor_avaliados se a classificação for maior que 7.4
			    if (rating > 7) {
				        HashMap<String, Object> item = new HashMap<>();
				        item.put("rating", lancamento.get("rating").toString());
				        item.put("name", lancamento.get("name").toString());
				        item.put("stream_id", lancamento.get("stream_id").toString());
				        item.put("stream_icon", lancamento.get("stream_icon").toString());
				
				        melhor_avaliados.add(item);
				    }
		}
		
		FileUtil.writeFile(FileUtil.getExternalStorageDir().concat("/serie/categoria/melhor_avaliado.json"), new Gson().toJson(melhor_avaliados));
		lanca.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/bebasneue.ttf"), 1);
		lanca.setText("MELHORES AVALIAÇÕES EM ".concat(new SimpleDateFormat("yyyy").format(vc.getTime())));
		canais_lista_categoria = new Gson().fromJson(FileUtil.readFile(FileUtil.getExternalStorageDir().concat("/serie/categoria/canais.json")), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		_grid2(canais_lista_categoria);
		melhorAvaliadaos = new Gson().fromJson(FileUtil.readFile(FileUtil.getExternalStorageDir().concat("/serie/categoria/melhor_avaliado.json")), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		categoriaSerie = new Gson().fromJson(FileUtil.readFile(FileUtil.getExternalStorageDir().concat("/serie/categoria/categoria.json")), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		_gird6(categoriaSerie);
		categoriasFilmes = new Gson().fromJson(FileUtil.readFile(FileUtil.getExternalStorageDir().concat("/serie/categoria/filmes.json")), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		_grid5(categoriasFilmes);
		melhor_avaliados.clear();
		melhor_avaliados = new Gson().fromJson(FileUtil.readFile(FileUtil.getExternalStorageDir().concat("/serie/categoria/melhor_avaliado.json")), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		_grid_from_list(melhor_avaliados);
	}
	
	@Override
	public void onBackPressed() {
		d.setMessage("Deseja fechar ?");
		d.setPositiveButton("SIM", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				finish();
			}
		});
		d.setNegativeButton("NÃO", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				
			}
		});
		d.create().show();
	}
	
	public void _grid2(final ArrayList<HashMap<String, Object>> _listmap) {
		GridView gridView = new GridView(this); // Cria uma nova instância de GridView
		
		// Define os parâmetros de layout do GridView
		gridView.setLayoutParams(new GridView.LayoutParams(_listmap.size() * (int) getDip(158), GridLayout.LayoutParams.WRAP_CONTENT));
		gridView.setBackgroundColor(Color.TRANSPARENT); // Define a cor de fundo como transparente
		
		gridView.setNumColumns(_listmap.size()); // Define o número de colunas com base no tamanho da lista
		gridView.setColumnWidth(GridView.AUTO_FIT); // Ajusta a largura das colunas automaticamente
		gridView.setVerticalSpacing(0); // Define o espaçamento vertical entre as linhas
		gridView.setHorizontalSpacing(0); // Define o espaçamento horizontal entre as colunas
		gridView.setStretchMode(GridView.STRETCH_COLUMN_WIDTH); // Estica as colunas para ocupar todo o espaço disponível
		
		// Define o adapter para o GridView
		gridView.setAdapter(new Listview2Adapter(_listmap)); // Substitua por seu adapter personalizado
		
		// Adiciona um listener para capturar cliques nos itens do GridView
		gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			    @Override
			    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				        
				it.putExtra("ver", "home");
				it.putExtra("voltar", "home");
				it.putExtra("category_name", canais_lista_categoria.get((int)position).get("category_name").toString());
				it.putExtra("category_id", canais_lista_categoria.get((int)position).get("category_id").toString());
				it.setClass(getApplicationContext(), CanaisActivity.class);
				startActivity(it);
				finish();
				
				    }
		});
		
		// Remove todas as views do layout linear
		linear_g1.removeAllViews(); // Remove todas as views de linear_g6
		
		// Adiciona o GridView ao layout linear
		linear_g1.addView(gridView); // Adiciona o GridView ao layout
		
	}
	
	
	public void _grid5(final ArrayList<HashMap<String, Object>> _listmap) {
		GridView gridView = new GridView(this); // Cria uma nova instância de GridView
		
		// Define os parâmetros de layout do GridView
		gridView.setLayoutParams(new GridView.LayoutParams(_listmap.size() * (int) getDip(158), GridLayout.LayoutParams.WRAP_CONTENT));
		gridView.setBackgroundColor(Color.TRANSPARENT); // Define a cor de fundo como transparente
		
		// Configurações adicionais do GridView
		gridView.setNumColumns(_listmap.size()); // Define o número de colunas com base no tamanho da lista
		gridView.setColumnWidth(GridView.AUTO_FIT); // Ajusta a largura das colunas automaticamente
		gridView.setVerticalSpacing(0); // Define o espaçamento vertical entre as linhas
		gridView.setHorizontalSpacing(0); // Define o espaçamento horizontal entre as colunas
		gridView.setStretchMode(GridView.STRETCH_COLUMN_WIDTH); // Estica as colunas para ocupar todo o espaço disponível
		gridView.invalidateViews(); // Invalida as views para forçar uma nova renderização
		
		// Define o adapter para o GridView
		gridView.setAdapter(new Listview5Adapter(_listmap)); // Substitua por seu adapter personalizado
		
		// Notifica que os dados do adapter mudaram
		((BaseAdapter) gridView.getAdapter()).notifyDataSetChanged();
		
		// Remove todas as views de linear_g5 e adiciona o GridView
		linear_g5.removeAllViews();
		linear_g5.addView(gridView);
		
		// Adiciona um listener para capturar cliques nos itens do GridView e mostrar a posição
		gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			    @Override
			    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				        // Exibe a posição do item clicado
				        
				it.putExtra("ver", "home");
				it.putExtra("voltar", "home");
				it.putExtra("category_name", categoriasFilmes.get((int)position).get("category_name").toString());
				it.putExtra("category_id", categoriasFilmes.get((int)position).get("category_id").toString());
				it.setClass(getApplicationContext(), CategoriaCanaisActivity.class);
				startActivity(it);
				finish();
				
				    }
		});
		
	}
	
	
	public void _gird6(final ArrayList<HashMap<String, Object>> _listmap) {
		GridView gridView = new GridView(this); // Cria uma nova instância de GridView
		
		// Define os parâmetros de layout do GridView
		gridView.setLayoutParams(new GridView.LayoutParams(_listmap.size() * (int) getDip(158), GridLayout.LayoutParams.WRAP_CONTENT));
		gridView.setBackgroundColor(Color.TRANSPARENT); // Define a cor de fundo como transparente
		
		gridView.setNumColumns(_listmap.size()); // Define o número de colunas com base no tamanho da lista
		gridView.setColumnWidth(GridView.AUTO_FIT); // Ajusta a largura das colunas automaticamente
		gridView.setVerticalSpacing(0); // Define o espaçamento vertical entre as linhas
		gridView.setHorizontalSpacing(0); // Define o espaçamento horizontal entre as colunas
		gridView.setStretchMode(GridView.STRETCH_COLUMN_WIDTH); // Estica as colunas para ocupar todo o espaço disponível
		
		// Define o adapter para o GridView
		gridView.setAdapter(new Listview6Adapter(_listmap)); // Substitua por seu adapter personalizado
		
		// Adiciona um listener para capturar cliques nos itens do GridView
		gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			    @Override
			    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				        
				it.putExtra("ver", "home");
				it.putExtra("voltar", "home");
				it.putExtra("category_name", categoriaSerie.get((int)position).get("category_name").toString());
				it.putExtra("category_id", categoriaSerie.get((int)position).get("category_id").toString());
				it.setClass(getApplicationContext(), SeriesActivity.class);
				startActivity(it);
				finish();
				
				    }
		});
		
		// Remove todas as views do layout linear
		linear_g6.removeAllViews(); // Remove todas as views de linear_g6
		
		// Adiciona o GridView ao layout linear
		linear_g6.addView(gridView); // Adiciona o GridView ao layout
		
	}
	
	
	public void _grid_from_list(final ArrayList<HashMap<String, Object>> _listmap) {
		GridView gridView = new GridView(this); // Cria uma nova instância de GridView
		
		// Define os parâmetros de layout do GridView
		gridView.setLayoutParams(new GridView.LayoutParams(_listmap.size() * (int) getDip(210), GridLayout.LayoutParams.WRAP_CONTENT));
		gridView.setBackgroundColor(Color.TRANSPARENT); // Define a cor de fundo como transparente
		
		// Configurações adicionais do GridView
		gridView.setNumColumns(_listmap.size()); // Define o número de colunas com base no tamanho da lista
		gridView.setColumnWidth(GridView.AUTO_FIT); // Ajusta a largura das colunas automaticamente
		gridView.setVerticalSpacing(0); // Define o espaçamento vertical entre as linhas
		gridView.setHorizontalSpacing(0); // Define o espaçamento horizontal entre as colunas
		gridView.setStretchMode(GridView.STRETCH_COLUMN_WIDTH); // Estica as colunas para ocupar todo o espaço disponível
		gridView.invalidateViews(); // Invalida as views para forçar uma nova renderização
		
		// Define o adapter para o GridView
		gridView.setAdapter(new Listview1Adapter(_listmap)); // Substitua por seu adapter personalizado
		
		// Notifica que os dados do adapter mudaram
		((BaseAdapter) gridView.getAdapter()).notifyDataSetChanged();
		
		// Remove todas as views de linear_g2 e adiciona o GridView
		linear_g2.removeAllViews();
		linear_g2.addView(gridView);
		
		// Adiciona um listener para capturar cliques nos itens do GridView e mostrar a posição
		gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			    @Override
			    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				        // Exibe a posição do item clicado
				        
				it.putExtra("voltar", "home");
				it.putExtra("stream_id", melhorAvaliadaos.get((int)position).get("stream_id").toString());
				it.setClass(getApplicationContext(), EspecificaoActivity.class);
				startActivity(it);
				finish();
				
				    }
		});
		
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.banner_grande, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			
			linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)0, Color.TRANSPARENT, 0xFF202020));
			Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("stream_icon").toString())).into(imageview1);
			textview1.setText(_data.get((int)_position).get("name").toString());
			textview2.setText("Avaliação ".concat(_data.get((int)_position).get("rating").toString()));
			imageview1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					it.putExtra("voltar", "home");
					it.putExtra("posicao", String.valueOf((long)(_position)));
					it.putExtra("stream_id", _data.get((int)_position).get("stream_id").toString());
					it.setClass(getApplicationContext(), EspecificaoActivity.class);
					startActivity(it);
					finish();
				}
			});
			
			return _view;
		}
	}
	
	public class Listview2Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview2Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.categoria, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			
			linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)0, Color.TRANSPARENT, 0xFF202020));
			textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/bebasneue.ttf"), 1);
			textview1.setText(_data.get((int)_position).get("category_name").toString());
			textview1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					it.putExtra("ver", "home");
					it.putExtra("voltar", "home");
					it.putExtra("category_name", _data.get((int)_position).get("category_name").toString());
					it.putExtra("category_id", _data.get((int)_position).get("category_id").toString());
					it.setClass(getApplicationContext(), CanaisActivity.class);
					startActivity(it);
					finish();
				}
			});
			
			return _view;
		}
	}
	
	public class Listview5Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview5Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.categoria, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			
			linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)0, Color.TRANSPARENT, 0xFF202020));
			textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/bebasneue.ttf"), 1);
			textview1.setText(_data.get((int)_position).get("category_name").toString());
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					it.putExtra("ver", "home");
					it.putExtra("voltar", "home");
					it.putExtra("category_name", _data.get((int)_position).get("category_name").toString());
					it.putExtra("category_id", _data.get((int)_position).get("category_id").toString());
					it.setClass(getApplicationContext(), CategoriaCanaisActivity.class);
					startActivity(it);
					finish();
				}
			});
			textview1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					it.putExtra("ver", "home");
					it.putExtra("voltar", "home");
					it.putExtra("category_name", _data.get((int)_position).get("category_name").toString());
					it.putExtra("category_id", _data.get((int)_position).get("category_id").toString());
					it.setClass(getApplicationContext(), CategoriaCanaisActivity.class);
					startActivity(it);
					finish();
				}
			});
			
			return _view;
		}
	}
	
	public class Listview6Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview6Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.categoria, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			
			linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)0, Color.TRANSPARENT, 0xFF202020));
			textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/bebasneue.ttf"), 1);
			textview1.setText(_data.get((int)_position).get("category_name").toString());
			textview1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					it.putExtra("ver", "home");
					it.putExtra("voltar", "home");
					it.putExtra("category_name", _data.get((int)_position).get("category_name").toString());
					it.putExtra("category_id", _data.get((int)_position).get("category_id").toString());
					it.setClass(getApplicationContext(), SeriesActivity.class);
					startActivity(it);
					finish();
				}
			});
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}