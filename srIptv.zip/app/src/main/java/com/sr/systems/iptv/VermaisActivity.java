package com.sr.systems.iptv;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.widget.GridView;
import android.content.res.Configuration;
import android.widget.Toast;

// Import necessário para UiModeManager
import android.app.UiModeManager;
import android.content.res.Configuration;
import android.content.pm.ActivityInfo;


public class VermaisActivity extends AppCompatActivity {
	
	private double list_number = 0;
	private double list_number2 = 0;
	
	private ArrayList<HashMap<String, Object>> lista = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> pesquisa = new ArrayList<>();
	
	private LinearLayout linear2;
	private LinearLayout linear3;
	private GridView gridview1;
	private LinearLayout linear4;
	private EditText edittext1;
	private ImageView imageview1;
	
	private Intent ir = new Intent();
	private Intent irj = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.vermais);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		
		// Obter o UiModeManager
		UiModeManager uiModeManager = (UiModeManager) getSystemService(UI_MODE_SERVICE);
		
		// Verificar se é um celular
		if (uiModeManager.getCurrentModeType() == Configuration.UI_MODE_TYPE_NORMAL) {
				    // É um celular, definir a orientação para vertical
				    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		} else {
				    // Não é um celular (pode ser tablet ou TV), definir a orientação para horizontal
				    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		}
		
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		gridview1 = findViewById(R.id.gridview1);
		linear4 = findViewById(R.id.linear4);
		edittext1 = findViewById(R.id.edittext1);
		imageview1 = findViewById(R.id.imageview1);
		
		gridview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (getIntent().getStringExtra("ver").equals("canais")) {
					irj.putExtra("voltar", "vermais");
					irj.putExtra("category_name", lista.get((int)_position).get("category_name").toString());
					irj.putExtra("category_id", lista.get((int)_position).get("category_id").toString());
					irj.putExtra("ver", "canais");
					irj.setClass(getApplicationContext(), CanaisActivity.class);
					startActivity(irj);
					finish();
				}
				else {
					if (getIntent().getStringExtra("ver").equals("filmes")) {
						irj.putExtra("voltar", "vermais");
						irj.putExtra("category_name", lista.get((int)_position).get("category_name").toString());
						irj.putExtra("category_id", lista.get((int)_position).get("category_id").toString());
						irj.putExtra("ver", "filmes");
						irj.setClass(getApplicationContext(), CategoriaCanaisActivity.class);
						startActivity(irj);
						finish();
					}
					else {
						if (getIntent().getStringExtra("ver").equals("series")) {
							irj.putExtra("voltar", "vermais");
							irj.putExtra("category_name", lista.get((int)_position).get("category_name").toString());
							irj.putExtra("category_id", lista.get((int)_position).get("category_id").toString());
							irj.putExtra("ver", "series");
							irj.setClass(getApplicationContext(), SeriesActivity.class);
							startActivity(irj);
							finish();
						}
					}
				}
			}
		});
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (getIntent().getStringExtra("ver").equals("canais")) {
					lista = new Gson().fromJson(FileUtil.readFile(FileUtil.getExternalStorageDir().concat("/serie/categoria/canais.json")), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					pesquisa = new Gson().fromJson(FileUtil.readFile(FileUtil.getExternalStorageDir().concat("/serie/categoria/canais.json")), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				}
				else {
					if (getIntent().getStringExtra("ver").equals("filmes")) {
						lista = new Gson().fromJson(FileUtil.readFile(FileUtil.getExternalStorageDir().concat("/serie/categoria/filmes.json")), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
						pesquisa = new Gson().fromJson(FileUtil.readFile(FileUtil.getExternalStorageDir().concat("/serie/categoria/filmes.json")), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					}
					else {
						if (getIntent().getStringExtra("ver").equals("series")) {
							lista = new Gson().fromJson(FileUtil.readFile(FileUtil.getExternalStorageDir().concat("/serie/categoria/categoria.json")), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
							pesquisa = new Gson().fromJson(FileUtil.readFile(FileUtil.getExternalStorageDir().concat("/serie/categoria/categoria.json")), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
						}
					}
				}
				if (_charSeq.equals("")) {
					gridview1.setAdapter(new Gridview1Adapter(lista));
					DisplayMetrics displayMetrics = new DisplayMetrics();
					    getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
					    
					    int larguraTela = displayMetrics.widthPixels;
					    int larguraItem = 300; // Defina a largura do item
					    
					    int numColunas = larguraTela / larguraItem;
					    if (numColunas < 1) {
						        numColunas = 1;
						    }
					    
					    gridview1.setNumColumns(numColunas);
				}
				else {
					if (_charSeq.length() > 0) {
						list_number = pesquisa.size() - 1;
						list_number2 = pesquisa.size();
						for(int _repeat24 = 0; _repeat24 < (int)(list_number2); _repeat24++) {
							if (pesquisa.get((int)list_number).get("category_name").toString().toLowerCase().contains(_charSeq.toLowerCase())) {
								
							}
							else {
								pesquisa.remove((int)(list_number));
							}
							list_number--;
						}
					}
				}
				gridview1.setAdapter(new Gridview1Adapter(pesquisa));
				DisplayMetrics displayMetrics = new DisplayMetrics();
				    getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
				    
				    int larguraTela = displayMetrics.widthPixels;
				    int larguraItem = 300; // Defina a largura do item
				    
				    int numColunas = larguraTela / larguraItem;
				    if (numColunas < 1) {
					        numColunas = 1;
					    }
				    
				    gridview1.setNumColumns(numColunas);
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
	}
	
	private void initializeLogic() {
		
		linear4.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)10, (int)0, Color.TRANSPARENT, 0xFF292C30));
		if (getIntent().getStringExtra("ver").equals("canais")) {
			lista = new Gson().fromJson(FileUtil.readFile(FileUtil.getExternalStorageDir().concat("/serie/categoria/canais.json")), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			gridview1.setAdapter(new Gridview1Adapter(lista));
			DisplayMetrics displayMetrics = new DisplayMetrics();
			    getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
			    
			    int larguraTela = displayMetrics.widthPixels;
			    int larguraItem = 350; // Defina a largura do item
			    
			    int numColunas = larguraTela / larguraItem;
			    if (numColunas < 1) {
				        numColunas = 1;
				    }
			    
			    gridview1.setNumColumns(numColunas);
		}
		else {
			if (getIntent().getStringExtra("ver").equals("filmes")) {
				lista = new Gson().fromJson(FileUtil.readFile(FileUtil.getExternalStorageDir().concat("/serie/categoria/filmes.json")), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				gridview1.setAdapter(new Gridview1Adapter(lista));
				DisplayMetrics displayMetrics = new DisplayMetrics();
				    getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
				    
				    int larguraTela = displayMetrics.widthPixels;
				    int larguraItem = 350; // Defina a largura do item
				    
				    int numColunas = larguraTela / larguraItem;
				    if (numColunas < 1) {
					        numColunas = 1;
					    }
				    
				    gridview1.setNumColumns(numColunas);
			}
			else {
				if (getIntent().getStringExtra("ver").equals("series")) {
					lista = new Gson().fromJson(FileUtil.readFile(FileUtil.getExternalStorageDir().concat("/serie/categoria/categoria.json")), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
					gridview1.setAdapter(new Gridview1Adapter(lista));
					DisplayMetrics displayMetrics = new DisplayMetrics();
					    getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
					    
					    int larguraTela = displayMetrics.widthPixels;
					    int larguraItem = 350; // Defina a largura do item
					    
					    int numColunas = larguraTela / larguraItem;
					    if (numColunas < 1) {
						        numColunas = 1;
						    }
					    
					    gridview1.setNumColumns(numColunas);
				}
			}
		}
	}
	
	@Override
	public void onBackPressed() {
		ir.setClass(getApplicationContext(), HomeActivity.class);
		startActivity(ir);
		finish();
	}
	
	public class Gridview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Gridview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.categoria_maior, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			
			linear1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)0, Color.TRANSPARENT, 0xFF292C30));
			textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/bebasneue.ttf"), 1);
			textview1.setText(_data.get((int)_position).get("category_name").toString());
			imageview1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					if (getIntent().getStringExtra("ver").equals("canais")) {
						irj.putExtra("voltar", "vermais");
						irj.putExtra("category_name", _data.get((int)_position).get("category_name").toString());
						irj.putExtra("category_id", _data.get((int)_position).get("category_id").toString());
						irj.putExtra("ver", "canais");
						irj.setClass(getApplicationContext(), CanaisActivity.class);
						startActivity(irj);
						finish();
					}
					else {
						if (getIntent().getStringExtra("ver").equals("filmes")) {
							irj.putExtra("voltar", "vermais");
							irj.putExtra("category_name", _data.get((int)_position).get("category_name").toString());
							irj.putExtra("category_id", _data.get((int)_position).get("category_id").toString());
							irj.putExtra("ver", "filmes");
							irj.setClass(getApplicationContext(), CategoriaCanaisActivity.class);
							startActivity(irj);
							finish();
						}
						else {
							if (getIntent().getStringExtra("ver").equals("series")) {
								irj.putExtra("voltar", "vermais");
								irj.putExtra("category_name", _data.get((int)_position).get("category_name").toString());
								irj.putExtra("category_id", _data.get((int)_position).get("category_id").toString());
								irj.putExtra("ver", "series");
								irj.setClass(getApplicationContext(), SeriesActivity.class);
								startActivity(irj);
								finish();
							}
						}
					}
				}
			});
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}