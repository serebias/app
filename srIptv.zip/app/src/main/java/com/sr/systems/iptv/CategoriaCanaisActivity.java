package com.sr.systems.iptv;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bumptech.glide.Glide;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
// Import necessário para UiModeManager
import android.app.UiModeManager;
import android.content.res.Configuration;
import android.content.pm.ActivityInfo;


public class CategoriaCanaisActivity extends AppCompatActivity {
	
	private String removerCaracteres = "";
	private double verPesquisa = 0;
	private double list_number = 0;
	private double list_number2 = 0;
	private String resultado = "";
	
	private ArrayList<HashMap<String, Object>> lista = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> pesquisa = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private GridView gridview1;
	private TextView pegarcategoria;
	private TextView categoria;
	private EditText pesquisar;
	private ImageView imageview1;
	
	private RequestNetwork obter;
	private RequestNetwork.RequestListener _obter_request_listener;
	private Intent it = new Intent();
	private SharedPreferences s;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.categoria_canais);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		
		// Obter o UiModeManager
		UiModeManager uiModeManager = (UiModeManager) getSystemService(UI_MODE_SERVICE);
		
		// Verificar se é um celular
		if (uiModeManager.getCurrentModeType() == Configuration.UI_MODE_TYPE_NORMAL) {
				    // É um celular, definir a orientação para vertical
				    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
		} else {
				    // Não é um celular (pode ser tablet ou TV), definir a orientação para horizontal
				    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		}
		
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		gridview1 = findViewById(R.id.gridview1);
		pegarcategoria = findViewById(R.id.pegarcategoria);
		categoria = findViewById(R.id.categoria);
		pesquisar = findViewById(R.id.pesquisar);
		imageview1 = findViewById(R.id.imageview1);
		obter = new RequestNetwork(this);
		s = getSharedPreferences("s", Activity.MODE_PRIVATE);
		
		gridview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				it.putExtra("ver", getIntent().getStringExtra("ver"));
				it.putExtra("voltar", "categoria");
				it.putExtra("stream_id", lista.get((int)_position).get("stream_id").toString());
				it.putExtra("category_name", getIntent().getStringExtra("category_name"));
				it.putExtra("category_id", getIntent().getStringExtra("category_id"));
				it.setClass(getApplicationContext(), EspecificaoActivity.class);
				startActivity(it);
				finish();
			}
		});
		
		pesquisar.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				lista = new Gson().fromJson(FileUtil.readFile(FileUtil.getExternalStorageDir().concat("/serie/categoria/filmes/".concat(pegarcategoria.getText().toString()))), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				pesquisa = new Gson().fromJson(FileUtil.readFile(FileUtil.getExternalStorageDir().concat("/serie/categoria/filmes/".concat(pegarcategoria.getText().toString()))), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				if (_charSeq.equals("")) {
					gridview1.setAdapter(new Gridview1Adapter(lista));
					DisplayMetrics displayMetrics = new DisplayMetrics();
					    getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
					    
					    int larguraTela = displayMetrics.widthPixels;
					    int larguraItem = 350; // Defina a largura do item
					    
					    int numColunas = larguraTela / larguraItem;
					    if (numColunas < 1) {
						        numColunas = 1;
						    }
					    
					    gridview1.setNumColumns(numColunas);
				}
				else {
					if (_charSeq.length() > 0) {
						list_number = pesquisa.size() - 1;
						list_number2 = pesquisa.size();
						for(int _repeat24 = 0; _repeat24 < (int)(list_number2); _repeat24++) {
							if (pesquisa.get((int)list_number).get("name").toString().toLowerCase().contains(_charSeq.toLowerCase())) {
								
							}
							else {
								pesquisa.remove((int)(list_number));
							}
							list_number--;
						}
					}
				}
				gridview1.setAdapter(new Gridview1Adapter(pesquisa));
				DisplayMetrics displayMetrics = new DisplayMetrics();
				    getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
				    
				    int larguraTela = displayMetrics.widthPixels;
				    int larguraItem = 350; // Defina a largura do item
				    
				    int numColunas = larguraTela / larguraItem;
				    if (numColunas < 1) {
					        numColunas = 1;
					    }
				    
				    gridview1.setNumColumns(numColunas);
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (verPesquisa == 0) {
					categoria.setVisibility(View.GONE);
					pesquisar.setVisibility(View.VISIBLE);
					verPesquisa = 1;
				}
				else {
					categoria.setVisibility(View.VISIBLE);
					pesquisar.setVisibility(View.GONE);
					verPesquisa = 0;
				}
			}
		});
		
		_obter_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				FileUtil.writeFile(FileUtil.getExternalStorageDir().concat("/serie/categoria/filmes/".concat(pegarcategoria.getText().toString())), _response);
				lista = new Gson().fromJson(FileUtil.readFile(FileUtil.getExternalStorageDir().concat("/serie/categoria/filmes/".concat(pegarcategoria.getText().toString()))), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
				gridview1.setAdapter(new Gridview1Adapter(lista));
				DisplayMetrics displayMetrics = new DisplayMetrics();
				    getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
				    
				    int larguraTela = displayMetrics.widthPixels;
				    int larguraItem = 350; // Defina a largura do item
				    
				    int numColunas = larguraTela / larguraItem;
				    if (numColunas < 1) {
					        numColunas = 1;
					    }
				    
				    gridview1.setNumColumns(numColunas);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		
		
		pesquisar.setVisibility(View.GONE);
		pesquisar.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)30, (int)0, Color.TRANSPARENT, 0xFF292C30));
		removerCaracteres = getIntent().getStringExtra("category_name").toUpperCase();
		String resultado = removerCaracteres.replaceAll("[^a-zA-Z0-9]", "_");
		pegarcategoria.setText("series".concat(resultado.concat(".json")));
		categoria.setText(getIntent().getStringExtra("category_name").toUpperCase());
		if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/serie/categoria/filmes/".concat(pegarcategoria.getText().toString())))) {
			lista = new Gson().fromJson(FileUtil.readFile(FileUtil.getExternalStorageDir().concat("/serie/categoria/filmes/".concat(pegarcategoria.getText().toString()))), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			gridview1.setAdapter(new Gridview1Adapter(lista));
			DisplayMetrics displayMetrics = new DisplayMetrics();
			    getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
			    
			    int larguraTela = displayMetrics.widthPixels;
			    int larguraItem = 350; // Defina a largura do item
			    
			    int numColunas = larguraTela / larguraItem;
			    if (numColunas < 1) {
				        numColunas = 1;
				    }
			    
			    gridview1.setNumColumns(numColunas);
			obter.startRequestNetwork(RequestNetworkController.GET, s.getString("dns", "").concat("/player_api.php?username=".concat(s.getString("usuario", "").concat("&password=".concat(s.getString("senha", "").concat("&action=get_vod_streams&category_id="))))).concat(getIntent().getStringExtra("category_id")), "obter", _obter_request_listener);
		}
		else {
			obter.startRequestNetwork(RequestNetworkController.GET, s.getString("dns", "").concat("/player_api.php?username=".concat(s.getString("usuario", "").concat("&password=".concat(s.getString("senha", "").concat("&action=get_vod_streams&category_id="))))).concat(getIntent().getStringExtra("category_id")), "obter", _obter_request_listener);
		}
	}
	
	@Override
	public void onBackPressed() {
		if (getIntent().getStringExtra("ver").equals("home")) {
			it.putExtra("ver", getIntent().getStringExtra("ver"));
			it.setClass(getApplicationContext(), HomeActivity.class);
			startActivity(it);
			finish();
		}
		else {
			it.putExtra("ver", getIntent().getStringExtra("ver"));
			it.setClass(getApplicationContext(), VermaisActivity.class);
			startActivity(it);
			finish();
		}
	}
	
	public class Gridview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Gridview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.banner_grande2, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			
			if (_data.get((int)_position).get("title").toString().toUpperCase().contains("xxx".toUpperCase())) {
				imageview1.setImageResource(R.drawable.xxx);
			}
			else {
				Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("stream_icon").toString())).into(imageview1);
			}
			textview1.setText(_data.get((int)_position).get("title").toString());
			textview2.setText("Avaliação ".concat(_data.get((int)_position).get("rating").toString()));
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}